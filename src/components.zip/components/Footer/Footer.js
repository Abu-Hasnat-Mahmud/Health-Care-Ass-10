import React from 'react';

const Footer = () => {
    return (
        <div className="container-fluid py-4 mt-3" style={{backgroundColor:'#0b114a'}}>
            <h6 className="text-center text-white">© Copyright By Himu 2021</h6>
        </div>
    );
};

export default Footer;