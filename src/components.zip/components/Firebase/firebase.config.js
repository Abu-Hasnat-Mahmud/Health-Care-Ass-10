

const firebaseConfig = {
    apiKey: "AIzaSyBVuJgx7T3PWGbvPPA3PxMTVkeV85JtOZI",
    authDomain: "health-care-9bdf0.firebaseapp.com",
    projectId: "health-care-9bdf0",
    storageBucket: "health-care-9bdf0.appspot.com",
    messagingSenderId: "943840302050",
    appId: "1:943840302050:web:41c9225b27fc8c2d01dfbb"
  };

  export default firebaseConfig;